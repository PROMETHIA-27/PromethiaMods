Rain of Stages Shared is a library for general interfacing with Risk of Rain 2 code via the Unity Editor.

Rain of Stages remains under development and contributions to the project are welcome

The project aims to provide many features to streamline the addition of many types of custom content for Risk of Rain 2.

Change Notes:

1.2.2:
	Fix Version numbers.

1.2.1:
   Improved JumpPad Editor
   Improved JumpPad Prefab